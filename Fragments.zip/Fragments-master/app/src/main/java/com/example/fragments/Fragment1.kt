package com.example.fragments

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import java.io.IOException
import java.util.*

class Fragment1 : Fragment() {

    private lateinit var btnVerifPerms: Button
    private lateinit var btnActivBT: Button
    private lateinit var btnPaired: Button
    private lateinit var btnClear: Button
    private lateinit var listView: ListView

    private lateinit var bluetoothManager: BluetoothManager
    private lateinit var bluetoothAdapter: BluetoothAdapter

    private val listeAppareils = mutableListOf<String>()

    // Demande de permissions
    private val requetePermissions: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            if (permissions.values.all { it }) {
                btnActivBT.isEnabled = true
                btnPaired.isEnabled = true
                btnClear.isEnabled = true
                Toast.makeText(activity, "Permissions OK", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(activity, "Permissions refusées", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_1, container, false)

        btnVerifPerms = view.findViewById(R.id.btnVerifPerms)
        btnActivBT = view.findViewById(R.id.btnActivBT)
        btnPaired = view.findViewById(R.id.btnPaired)
        btnClear = view.findViewById(R.id.btnClear)
        listView = view.findViewById(R.id.listView)

        btnVerifPerms.isEnabled = false
        btnActivBT.isEnabled = false
        btnPaired.isEnabled = false
        btnClear.isEnabled = false

        val manager = activity?.getSystemService(Context.BLUETOOTH_SERVICE)
        if (manager is BluetoothManager) {
            bluetoothManager = manager
            bluetoothAdapter = bluetoothManager.adapter

            if (bluetoothAdapter == null) {
                Toast.makeText(activity, "Bluetooth non disponible", Toast.LENGTH_SHORT).show()
            } else {
                btnVerifPerms.isEnabled = true
                Toast.makeText(activity, "Bluetooth prêt", Toast.LENGTH_SHORT).show()
            }
        }

        btnVerifPerms.setOnClickListener {
            val BT_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            } else {
                arrayOf(
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            }
            requetePermissions.launch(BT_PERMISSIONS)
        }

        btnActivBT.setOnClickListener {
            if (bluetoothAdapter.isEnabled) {
                Toast.makeText(activity, "Bluetooth déjà activé", Toast.LENGTH_SHORT).show()
            } else {
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivity(enableBtIntent)
            }
        }

        // 🔹 Liste des appareils appairés
        btnPaired.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
            ) {
                Toast.makeText(requireContext(), "Permission BLUETOOTH_CONNECT requise", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            listeAppareils.clear()
            val pairedDevices: Set<BluetoothDevice> = bluetoothAdapter.bondedDevices
            pairedDevices.forEach { device ->
                val name = device.name ?: "Inconnu"
                val address = device.address
                listeAppareils.add("$name\n$address")
            }

            val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, listeAppareils)
            listView.adapter = adapter

            // 🔹 Sélection d’un appareil
            listView.setOnItemClickListener { _, _, pos, _ ->
                val address = listeAppareils[pos].split('\n')[1]

                if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    Toast.makeText(requireContext(), "Permission requise pour se connecter", Toast.LENGTH_SHORT).show()
                    return@setOnItemClickListener
                }

                val device = bluetoothAdapter.getRemoteDevice(address)
                Log.i("BT", "Device choisi - ${device.name} - $address")
                ConnectThread(device).start()
            }
        }

        // 🔹 Vider la liste
        btnClear.setOnClickListener {
            listeAppareils.clear()
            (listView.adapter as? ArrayAdapter<*>)?.notifyDataSetChanged()
        }

        return view
    }

    // 🔹 Thread de connexion Bluetooth
    inner class ConnectThread(private val device: BluetoothDevice) : Thread() {
        private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private val mmSocket: BluetoothSocket? = try {
            device.createRfcommSocketToServiceRecord(uuid)
        } catch (e: IOException) {
            Log.e("BT", "Erreur création socket", e)
            null
        }

        override fun run() {
            bluetoothAdapter.cancelDiscovery()
            try {
                mmSocket?.connect()
                Log.i("BT", "Connexion réussie avec ${device.name}")
                // TODO : démarrer un thread de lecture si besoin
            } catch (e: IOException) {
                Log.e("BT", "Erreur de connexion", e)
                try {
                    mmSocket?.close()
                } catch (closeException: IOException) {
                    Log.e("BT", "Erreur fermeture socket", closeException)
                }
            }
        }
    }
}
